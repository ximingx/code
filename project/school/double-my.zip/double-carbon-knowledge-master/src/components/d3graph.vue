<template>
  <div style="height: 100%;width: 100%">
    <div class="search-bar" style=" height: 20%; max-height:186px;">
      <el-row :gutter="20" style="padding-top: 10px;margin-left: 50px;">
        <el-col :span="17" style="padding-left: 0px">
          <el-input v-model="keywords" clearable placeholder=""
                    size="medium" :disabled="inputDisable" style="height: 75px; padding-top: 10px;"/>
        </el-col>
        <el-col :span="3" style="margin-top: 10px;">
          <el-button type="primary" icon="el-icon-search" size="medium" @click="searchKeyWords" id="ButtonID"
                     v-loading.fullscreen.lock="fullscreenLoading">搜索
          </el-button>
        </el-col>
        <el-col :span="3" style="margin-top: 10px; padding-right: 53px; text-align: center; padding-left: 0px">
          <el-button type="primary" icon="el-icon-refresh" size="medium" @click="clearKeyWords"
                     v-loading.fullscreen.lock="fullscreenLoading">重置
          </el-button>
        </el-col>
      </el-row>
      <el-row :gutter=80 style="margin-left: 50px;">
        <el-col :span="7" style="padding-left: 0px;padding-right: 0px;text-align: left;">
          <span class="policyFont">患病名称: </span>
          <el-select v-model="kgValue" style="display: inline-block ">
            <el-option
              v-if="(item==='') ? item = '无':item"
              v-for="(item,i) in kgOptions"
              :key="i"
              :label="item"
              :value="item"
              :disabled="item.disabled">
            </el-option>
          </el-select>
        </el-col>
        <el-col :span="7" style="padding-left: 0px;padding-right: 0px;text-align: left;">
          <span class="policyFont">发病部位: </span>
          <el-select v-model="originalValue" style="display: inline-block">
            <el-option
              v-if="(item==='') ? item = '无':item"
              v-for="(item,i) in originalOptions"
              :key="i"
              :label="item"
              :value="item"
              :disabled="item.disabled">
            </el-option>
          </el-select>
        </el-col>
        <el-col :span="7" style="padding-left: 0px;padding-right: 0px;text-align: left;">
          <span class="policyFont">相关症状: </span>
          <el-select v-model="typeValue" style="display: inline-block">
            <el-option
              v-if="(item==='') ? item = '无':item"
              v-for="(item,i) in typeOptions"
              :key="i"
              :label="item"
              :value="item"
              :disabled="item.disabled">
            </el-option>
          </el-select>
        </el-col>
        <el-col :span="7" style="padding-left: 0px;padding-right: 0px;text-align: left;">
          <span class="policyFont">治疗周期: </span>
          <el-select v-model="yearValue" style="display: inline-block">
            <el-option
              v-if="(item==='') ? item = '无':item"
              v-for="(item,i) in yearOptions"
              :key="i"
              :label="item"
              :value="item"
              :disabled="item.disabled">
            </el-option>
          </el-select>
        </el-col>
        <el-col :span="7" style="padding-left: 10px;padding-right: 0px;text-align: left;">
          <span class="policyFont">治愈率:</span>
          <el-select v-model="qtValue" style="display: inline-block">
            <el-option
              v-for="item in qtOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
              :disabled="item.disabled">
            </el-option>
          </el-select>
        </el-col>
      </el-row>
    </div>
    <svg
      id="svg"
      width="80%"
      height="70%"
    ></svg>
    <!-- 绘制图例 -->
    <div id="indicator" :style="{'--indicator_left':this.indicator_left,'--indicator_top':this.indicator_top}">
      <!-- 利用item 遍历一个数组 利用index 遍历另外一个数组 -->
      <div v-for="(name, index) in names" :key="index">
        <span
          @click="hideNodeOfType"
          :data-state="states[index]"
          :data-index="index"
          style="cursor: pointer;"
          :style="{ backgroundColor: states[index] === 'on' ? colors[index] : '#ea8181' }"
        ></span>
        <span style="color: #888888;width: auto">{{ name }}</span>
      </div>
    </div>
    <!-- 绘制右边显示结果 -->
    <div id="info" :style="{'--info_top': this.info_top}" v-show="selectNodeData.name !== undefined">
      <!-- <h4 :style="{ color: selectNodeData.color }">{{ selectNodeData.name }}</h4>
      <p v-for="(item, key) in selectNodeData.properties" :key="item">
        <span>{{ key }}</span>
        {{ item }}
      </p> -->
      <el-card
        :style="{ backgroundColor: selectNodeData.color }"
        class="node-card"
      >
        <div slot="header" class="clearfix">
          <span>{{ selectNodeData.name }}</span>
          <!--          <el-button-->
          <!--            @click="btnEdit"-->
          <!--            style="float: right; padding: 3px 0;color: #409EFB;font-size: 15px;"-->
          <!--            type="text"-->
          <!--          >编辑-->
          <!--          </el-button>-->
        </div>
        <div
          v-for="(item, index) in selectNodeData.properties" :key="index"
        >
          <span style="margin-right: 8px;"
                v-if="item&&index!='name'">{{ (nodeObjMap[index] ? nodeObjMap[index] : index) + ':' }}</span>
          <span style="text-align: right;" v-if="index!='name'">
            <b v-if="nodeObjMap[index]==='政策内容'&&item!=None">
              <a :href="'http://39.101.74.24:8000/list-info?policyId='+item">链接</a>
            </b>
            <b v-else-if=" (item=='None') ? item='无' :item">{{ item }}</b>
          </span>
        </div>
      </el-card>
    </div>
  </div>
</template>

<script>
import * as d3 from 'd3'
import install from '@/plugins/d3-context-menu';
import axios from "axios";

install(d3) // 为d3注册右键菜单插件
export default {
  name: 'd3graph',
  props: {
    data: {
      type: Object,
      default: function () {
        return {
          nodes: [],
          links: []
        }
      }
    },
    /* eslint-disable */
    // 自定义图例（数组保证一一对应）
    // names		图例名称变量制作图标
    // labels		节点的标签名称（与records.json中保证相同）
    names: {
      type: Array
    },
    labels: Array,
    linkTypes: Array
  },
  data() {
    return {
      inputDisable: false,
      fullscreenLoading: false,
      info_top: 0,
      indicator_left: 0,
      indicator_right: 0,
      svgDom: null, // svg的DOM元素 => d3.select('#svg1')
      keywords: '',
      nodeState: 0,
      // 文本状态，表示是否显示文本信息（0：显示/1：不显示）
      textState: 0,
      // d3render()最终展示到页面上的数据（节点隐藏功能）
      nodes: [],
      links: [],
      /* eslint-disable */
      // 自定义图例及颜色（数组保证一一对应）
      // colors		图例颜色（9个颜色）
      // states   图例状态（on：显示 / off：不显示）
      colors: ['#0361d2', '#aaaaff', '#4e88af', '#9d76e7', '#FFC0CB', '#BA55D3', '#1E90FF', '#7FFFD4', '#FFFF00'],
      states: [],
      selectNodeData: {}, // 选中节点的详细信息展示
      isNodeClicked: false, // 是否点击（选中）节点
      // 用于位置、大小矫正（暂不使用）
      // svgTranslate: [240, 130],
      // svgScale: 0.5,
      // 右击事件的菜单栏
      menu: [
        {
          title: '隐藏节点',
          action: (elm, d) => {
            console.log(d)
            // 遍历删除节点
            this.nodes = this.nodes.filter(node => {
              if (node.id === d.id) return false
              else return true
            })
            // 遍历删除关系
            this.links = this.links.filter(link => {
              if (link.source.id === d.id || link.target.id === d.id) return false
              else return true
            })
            this.d3render() // 重新渲染图
            this.stateInit()
          },
          disabled: false // optional, defaults to false
        },
        {
          title: '显示节点关联图',
          action: (elm, d) => {
            console.log(d)
            // 遍历保留对应节点
            this.nodes = this.data.nodes.filter(node => {
              if (node.id === d.id) return true
              else {
                for (var i = 0; i < this.data.links.length; i++) {
                  // 如果links的起点等于name，并且终点等于正在处理的则显示
                  if (this.data.links[i].source.id === node.id && this.data.links[i].target.id === d.id) {
                    return true
                  }
                  if (this.data.links[i].target.id === node.id && this.data.links[i].source.id === d.id) {
                    return true
                  }
                }
                return false
              }
            })
            // 遍历保留节点的关联关系
            this.links = this.data.links.filter(link => {
              if (link.source.id === d.id || link.target.id === d.id) return true
              else return false
            })
            this.d3render() // 重新渲染图
            this.stateInit()
          }
        },
        {
          title: '显示所有查询节点',
          action: (elm, d) => {
            this.nodes = this.data.nodes
            // 遍历保留节点的关联关系
            this.links = this.data.links
            this.d3render() // 重新渲染图
            this.stateInit()
          }
        }
      ],
      temp: {}, // 临时存储编辑时的节点信息
      dialogFormVisible: false,
      isEdit: true,
      // 节点属性对应的标签名称
      nodeObjMap: {
        "disease_name": '患病名称',
        "intro": '简介',
        "pathogenic_site": '发病部位',
        "correlation": '相关症状',
        "treatment_cycle": '治疗周期',
        "cure_rate": '治愈率'
      },
      kgValue: '无',
      originalValue: '无',
      typeValue: '无',
      yearValue: '无',
      qtValue: '无',
      kgTemp: '无',
      originalTemp: '无',
      typeTemp: '无',
      yearTemp: '无',
      searchValue: '',
      kgOptions: [],
      originalOptions: [],
      typeOptions: [],
      yearOptions: [],
      qtOptions: [{
        value: '无',
        label: '无'
      }],
    }
  },
  computed: {
    isShowNode: function () {
      // `this` 指向 vm 实例
      return this.nodeState === 0
    },
    isShowText: function () {
      // `this` 指向 vm 实例
      return this.textState === 0
    },
    gDensity() {
      return this.nodes.length <= 1 ? 0 : (this.links.length / (this.nodes.length * (this.nodes.length - 1))).toFixed(2)
    },
    gDegree() {
      return (this.links.length / this.nodes.length).toFixed(2)
    },
    // 企业实体的平均度数
    gMainDegree() {
      // 遍历节点
      // this.nodes.forEach(node => {
      //
      // })
      // // 遍历关系
      // this.links.forEach(link => {
      //
      // })
    },
    // 稀疏度
    gSparsity() {
      return (this.links.length / (this.nodes.length * Math.log(this.nodes.length))).toFixed(2)
    }
  },
  watch: {
    // 当请求到新的数据时，重新渲染
    data(newData, oldData) {
      console.log(newData, oldData)
      // 移除svg和元素注册事件，防止内存泄漏
      this.svgDom.on('.', null)
      this.searchValue = this.keywords
      this.svgDom.selectAll('*').on('.', null)
      this.d3init()
      if (this.keywords === '') {
        this.clearGraphStyle()
      } else {
        var name = this.keywords
        console.log(name)
        // 搜索所有的节点
        this.svgDom.select('.nodes').selectAll('circle').attr('class', d => {
          // 输入节点id的小写等于name则显示，否则隐藏
          if (d.properties.name.indexOf(name) >= 0) {
            return 'fixed'
          } else {
            // 优化：与该搜索节点相关联的节点均显示
            // links链接的起始节点进行判断,如果其id等于name则显示这类节点
            // 注意: graph=data
            for (var i = 0; i < this.links.length; i++) {
              // 如果links的起点等于name，并且终点等于正在处理的则显示
              if ((this.links[i]['source'].properties.name.indexOf(name) >= 0) &&
                (this.links[i]['target'].id == d.id)) {
                return 'active'
              }
              // 如果links的终点等于name，并且起点等于正在处理的则显示
              if ((this.links[i]['target'].properties.name.indexOf(name) >= 0) &&
                (this.links[i]['source'].id == d.id)) {
                return 'active'
              }
            }
            return 'inactive' // 隐藏
          }
        })
        // 搜索texts
        this.svgDom.select('.texts').selectAll('text').attr('class', d => {
          if (d.properties.name.indexOf(name) >= 0) {
            return ''
          } else {
            // 优化：与该搜索节点相关联的节点均显示
            // links链接的起始节点进行判断,如果其id等于name则显示这类节点
            for (var i = 0; i < this.links.length; i++) {
              // 如果links的起点等于name，并且终点等于正在处理的则显示
              if ((this.links[i]['source'].properties.name.indexOf(name) >= 0) &&
                (this.links[i]['target'].id == d.id)) {
                return ''
              }
              //如果links的终点等于name，并且起点等于正在处理的则显示
              if ((this.links[i]['target'].properties.name.indexOf(name) >= 0) &&
                (this.links[i]['source'].id == d.id)) {
                return ''
              }
            }
            return 'inactive'
          }
        })
        // 搜索links
        // 显示相的邻边 注意 ||
        this.svgDom.select(".links").selectAll('line').attr('class', d => {
          if ((d.source.properties.name.indexOf(name) >= 0) ||
            (d.target.properties.name.indexOf(name) >= 0)
          ) {
            return ''
          } else {
            return 'inactive' //隐藏
          }
        })
        // 搜索linkTexts
        this.svgDom.select(".linkTexts").selectAll('text').attr('class', d => {
          if ((d.source.properties.name.indexOf(name) >= 0) ||
            (d.target.properties.name.indexOf(name) >= 0)
          ) {
            return ''
          } else {
            return 'inactive' //隐藏
          }
        })
      }
    }
    // kgValue: 'onChange',
    // originalValue: 'onChange',
    // typeValue: 'onChange',
    // yearValue: 'onChange',
  },
  created() {
    // this.states = Array(this.names.length).fill('on')
  },
  mounted() {
    this.selectInit()
    //图数据初始化
    this.d3init()
    //下拉框初始化
    window.onresize = () => {
      var position = document.getElementById('svg').getBoundingClientRect();
      this.info_top = (position.top + 20) + 'px'
      this.indicator_left = (position.left + 20) + 'px'
      this.indicator_top = (position.bottom - 20 - 145) + 'px'
      this.$events.$emit('resize')
    }
    var position = document.getElementById('svg').getBoundingClientRect();
    this.info_top = (position.top + 20) + 'px'
    this.indicator_left = (position.left + 20) + 'px'
    this.indicator_top = (position.bottom - 20 - 145) + 'px'
    this.$events.$on('setfullscreenLoading', (fullscreenLoading) => {
      this.fullscreenLoading = fullscreenLoading
    })
  },
  beforeDestroy() {
    // 移除svg和元素注册事件，防止内存泄漏
    this.svgDom.on('.', null)
    this.svgDom.selectAll('*').on('.', null)
  },
  methods: {
    selectInit() {
      axios({
        method: 'post',
        url: 'http://39.101.74.24:8081/hugegraph/selectDocauthor',
      })
        .then((res) => {
          this.kgOptions = res.data
        });
      axios({
        method: 'post',
        url: 'http://39.101.74.24:8081/hugegraph/selectDocsource',
      })
        .then((res) => {
          this.originalOptions = res.data
        })
      axios({
        method: 'post',
        url: 'http://39.101.74.24:8081//hugegraph/selectTypename',
      })
        .then((res) => {
          this.typeOptions = res.data
        })
      axios({
        method: 'post',
        url: 'http://39.101.74.24:8081/hugegraph/selectYears',
      })
        .then((res) => {
          this.yearOptions = res.data
        })
    },
    onChange(val, oldV) {
      if ((this.kgValue == '' || this.kgValue == '无') && (this.originalValue == '' || this.originalValue == '无') && (this.typeValue == '' || this.typeValue == '无') && (this.yearValue == '' || this.yearValue == '无')) {
        this.inputDisable = false;
      } else {
        this.inputDisable = true;
      }
    },
    // 编辑当前选中节点
    btnEdit() {
      this.temp = Object.assign({}, this.selectNodeData.properties) // copy obj
      this.dialogFormVisible = true
      console.log(this.selectNodeData)
    },
    doEdit() {
      // console.log(this.data)
      let i = 0
      // 更新props的data 和 selectNodeData
      this.selectNodeData.name = this.temp.name
      this.selectNodeData.properties = this.temp
      for (let node of this.data.nodes) {
        // console.log(node.id === this.selectNodeData.id)
        // console.log(node.id)
        // console.log(this.selectNodeData.id)
        if (node.id == this.selectNodeData.id) {
          // this.$set(this.data.nodes, i, this.selectNodeData)
          // this.$set(this.nodes, i, this.selectNodeData)
          this.data.nodes[i].properties = this.temp
          this.nodes[i].properties = this.temp
          break
        }
        i++
      }
      this.dialogFormVisible = false
      this.d3init()
      this.$message({
        message: '更新成功',
        type: 'success'
      })
    },
    cancelEdit() {
      this.dialogFormVisible = false
    },
    // 隐藏文字
    changeTextState(state) {
      // state发生变化时才进行更新、处理
      if (this.textState !== state) {
        this.textState = state
        // const text = d3.selectAll('.texts text')
        const text = d3.selectAll('.linkTexts text')
        console.log(text)
        // 根据新的节点状态，在节点上展示不同的文本信息
        if (this.textState === 2) {
          text.style('display', 'none')
          // 暂不作校准
          // // transform属性数值化
          // // 原：translate(40, 8) scale(1)
          // // 现：[40, 8, 1]
          // let transform = d3.select('#svg1 g').attr('transform')
          // transform = transform
          //   ? transform.match(/\d.?/g).map(item => parseInt(item))
          //   : [0, 0, 1]
          // // 校准
          // transform[0] = transform[0] + this.svgTranslate[0]
          // transform[1] = transform[1] + this.svgTranslate[1]
          // transform[2] = transform[2] * this.svgScale

          // console.log(transform)
          // // 隐藏节点后，svg自动缩放
          // d3.select('#svg1 g').attr('transform', 'translate(' + transform[0] + ', ' + transform[1] + ') scale(' + transform[2] + ')')
        } else {
          text.style('display', 'block')
          // 暂不作校准
          // 显示节点后，svg自动还原
          // d3.select('#svg1 g').attr('transform', '')
        }
      }
    },
    // 隐藏该类型的所有节点（图例）
    hideNodeOfType(event) {
      if (this.nodes.length === this.data.nodes.length
        || this.states.some((state) => state === 'off')) {
        // console.log(event.target.dataset)
        const index = event.target.dataset.index
        const state = event.target.dataset.state
        // const nodeTypes = ['Enterprise', 'Type', 'Region', 'Country']
        // const linkTypes = ['', 'type', 'locate', 'export']
        // 图例的状态切换（对应类型的节点隐藏）
        if (state === 'on') {
          // 隐藏该类型的所有节点及关联关系
          // this.states[index] = 'off'
          this.$set(this.states, index, 'off')
        } else {
          // this.states[index] = 'on'
          this.$set(this.states, index, 'on')
        }
        /**************************************
         * 状态更新后，同时对数据更新
         */
        const indexs = this.states.map(s => {
          if (s === 'on') {
            return '1'
          } else {
            return '0'
          }
        })
        // 遍历删除节点
        this.nodes = this.data.nodes.filter(node => {
          for (let i = 0; i < indexs.length; i++) {
            if (node.label === this.labels[i] && indexs[i] === '0') return false
          }
          return true
        })
        // 遍历删除关系
        this.links = this.data.links.filter(link => {
          for (let i = 0; i < indexs.length; i++) {
            if (i === 0 && indexs[i] === '0') return false
            else if (link.type === this.linkTypes[i] && indexs[i] === '0') return false
          }
          return true
        })
        // 调试时使用
        // console.log(indexs)
        // console.log(this.data.nodes.length, this.data.links.length)
        // console.log(this.nodes.length)
        // console.log(this.links.length)
        // 重新渲染
        this.d3render()
      } else {
        this.$message.error('展示全部节点时才能隐藏图例')
      }
    },

    clearKeyWords() {
      this.kgValue = '无';
      this.originalValue = '无';
      this.typeValue = '无';
      this.yearValue = '无';
      this.qtValue = '无';
      this.keywords = '';
      this.yearTemp = this.yearValue;
      this.kgTe最·mp = this.kgValue;
      this.typeTemp = this.typeValue;
      this.originalTemp = this.originalValue;
      this.fullscreenLoading = true;
      this.$events.$emit('clearKey');
    },
    // 搜索包含关键字的节点
    searchKeyWords(value) {
      // 如果Input值是空的显示所有的圆和线(没有进行筛选)
      if ((this.kgValue != this.kgTemp) ||
        (this.typeValue != this.typeTemp) ||
        (this.originalValue != this.originalTemp) ||
        (this.yearValue != this.yearTemp)) {
        this.yearTemp = this.yearValue;
        this.kgTemp = this.kgValue;
        this.typeTemp = this.typeValue;
        this.originalTemp = this.originalValue;
        this.fullscreenLoading = true;
        this.$events.$emit('change',
          this.kgValue,
          this.originalValue,
          this.typeValue,
          this.yearValue,
          this.fullscreenLoading,
        );
      }
      if (this.keywords === '') {
        this.clearGraphStyle()
      }
      // 否则判断判断三个元素是否等于name值，等于则显示该值
      else {
        var name = this.keywords
        console.log(name)
        // 搜索所有的节点
        this.svgDom.select('.nodes').selectAll('circle').attr('class', d => {
          // 输入节点id的小写等于name则显示，否则隐藏
          if (d.properties.name.indexOf(name) >= 0) {
            //todo
            return 'fixed'
          } else {
            // 优化：与该搜索节点相关联的节点均显示
            // links链接的起始节点进行判断,如果其id等于name则显示这类节点
            // 注意: graph=data
            for (var i = 0; i < this.links.length; i++) {
              // 如果links的起点等于name，并且终点等于正在处理的则显示
              if ((this.links[i]['source'].properties.name.indexOf(name) >= 0) &&
                (this.links[i]['target'].id == d.id)) {
                return 'active'
              }
              // 如果links的终点等于name，并且起点等于正在处理的则显示
              if ((this.links[i]['target'].properties.name.indexOf(name) >= 0) &&
                (this.links[i]['source'].id == d.id)) {
                return 'active'
              }
            }
            return 'inactive' // 隐藏
          }
        })
        // 搜索texts
        this.svgDom.select('.texts').selectAll('text').attr('class', d => {
          if (d.properties.name.indexOf(name) >= 0) {
            return 'fixed'
          } else {
            // 优化：与该搜索节点相关联的节点均显示
            // links链接的起始节点进行判断,如果其id等于name则显示这类节点
            for (var i = 0; i < this.links.length; i++) {
              // 如果links的起点等于name，并且终点等于正在处理的则显示
              if ((this.links[i]['source'].properties.name.indexOf(name) >= 0) &&
                (this.links[i]['target'].id == d.id)) {
                return 'active'
              }
              //如果links的终点等于name，并且起点等于正在处理的则显示
              if ((this.links[i]['target'].properties.name.indexOf(name) >= 0) &&
                (this.links[i]['source'].id == d.id)) {
                return 'active'
              }
            }
            return 'inactive'
          }
        })
        // 搜索links
        // 显示相的邻边 注意 ||
        this.svgDom.select(".links").selectAll('line').attr('class', d => {
          if ((d.source.properties.name.indexOf(name) >= 0) ||
            (d.target.properties.name.indexOf(name) >= 0)
          ) {
            return ''
          } else {
            return 'inactive' //隐藏
          }
        })
        // 搜索linkTexts
        this.svgDom.select(".linkTexts").selectAll('text').attr('class', d => {
          if ((d.source.properties.name.indexOf(name) >= 0) ||
            (d.target.properties.name.indexOf(name) >= 0)
          ) {
            return ''
          } else {
            return 'inactive' //隐藏
          }
        })
      }
    },
    // d3初始化，包括数据解析、数据渲染
    d3init() {
      this.links = this.data.links
      this.nodes = this.data.nodes
      this.svgDom = d3.select('#svg')  // 获取svg的DOM元素
      // this.d3jsonParser(this.graph)
      this.d3render()
      // 数据状态初始化
      this.stateInit()
    },
    // 数据状态初始化
    stateInit() {
      this.nodeState = 0
      this.textState = 0
      // console.log(this.names)
      this.states = Array(this.names.length).fill('on')
    },
    d3render() {
      var _this = this // 临时获取Vue实例，避免与d3的this指针冲突

      // 渲染前清空svg内的元素
      _this.svgDom.selectAll('*').remove()
      // svg.selectAll('g').remove()

      var svg = _this.svgDom
        .on('click', () => {
          // console.log(this.isNodeClicked)
          this.isNodeClicked = false
          // 移除所有样式
          this.clearGraphStyle()
          // 如果此时有搜索关键字，则鼠标离开时保留原搜索选中的节点
          if (this.keywords !== '') {
            this.searchKeyWords()
          }
        })
        // 给画布绑定zoom事件（缩放、平移）
        .call(d3.zoom().on('zoom', event => {
          // console.log(event)
          var scale = event.transform.k,
            translate = [event.transform.x, event.transform.y]

          // if (this.svgTranslate) {
          //     translate[0] += this.svgTranslate[0]
          //     translate[1] += this.svgTranslate[1]
          // }

          // if (this.svgScale) {
          //     scale *= this.svgScale
          // }

          svg.attr('transform', 'translate(' + translate[0] + ', ' + translate[1] + ') scale(' + scale + ')');
        }))
        .append('g')
        .attr('width', '100%')
        .attr('height', '100%')

      this.addMarkers()
      // console.log(svg)
      // 动态变化时，不再固定宽高
      // var width = svg.attr("width"),
      //     height = svg.attr("height")

      // 解析json和数据处理
      // 现在解析json直接在d3jsonParser()中更新nodes和links
      // const data = this.d3jsonParser(this.graph)
      // this.links = data.links.map(d => Object.create(d))
      // this.nodes = data.nodes.map(d => Object.create(d))

      // 定义碰撞检测模型
      var forceCollide = d3.forceCollide()
        .radius(d => {
          return 16 * 3
        })
        .iterations(0.15)
        .strength(0.75)

      // 利用d3.forceSimulation()定义关系图 包括设置边link、排斥电荷charge、关系图中心点
      var simulation = d3.forceSimulation(this.nodes)
        .force("link", d3.forceLink().id(d => d.id))
        .force("charge", d3.forceManyBody().strength(-100))
        // .force("center", d3.forceCenter(width / 2, height / 2)
        .force("center", d3.forceCenter(svg.node().parentElement.clientWidth / 2, svg.node().parentElement.clientHeight / 2))
        .force("collision", forceCollide)

      // D3映射数据至HTML中
      // g用于绘制所有边,selectALL选中所有的line,并绑定数据data(graph.links),enter().append("line")添加元素
      // 数据驱动文档,设置边的粗细
      var link = svg.append("g")
        .attr("class", "links")
        .selectAll("line")
        .data(this.links).enter()
        .append("line")
        .attr("stroke-width", function (d) {
          // 每次访问links的一项数据
          return 2 //所有线宽度均为2
        })
        .join("path")
        .attr("marker-end", "url(#posMarker)")

      var linksName = svg.append("g")
        .attr("class", "linkTexts")
        .selectAll("text")
        .data(this.links)
        .join("text")
        .style('text-anchor', 'middle')
        .style('fill', '#fff')
        .style('font-size', '12px')
        // .style('font-weight', 'bold')
        .text(d => d.properties.name)

      // linksName
      //   .append('textPath')
      //   .attr('xlink:href', d => '#')
      //   .attr('startOffset', '50%')

      // 添加所有的点
      // selectAll("circle")选中所有的圆并绑定数据,圆的直径为d.size
      // 再定义圆的填充色,同样数据驱动样式,圆没有描边,圆的名字为d.id
      // call()函数：拖动函数,当拖动开始绑定dragstarted函数，拖动进行和拖动结束也绑定函数
      var node = svg.append("g")
        .attr("class", "nodes")
        .selectAll("circle")
        .data(this.nodes).enter()
        .append("circle").attr("r", function (d) {
          // 每次访问nodes的一项数据
          // console.log(d)
          let size = 15
          switch (d.label) {
            case _this.labels[0]:
              break;
            case _this.labels[1]:
              size = 15;
              break;
            case _this.labels[2]:
              size = 15;
              break;
            default:
              size = 15;
              break;
          }
          return size * 2
        })
        .attr("fill", d => {
          for (let i = 0; i < this.labels.length; i++) {
            if (d.label === this.labels[i]) return this.colors[i]
          }
        })
        .attr("stroke", "none")
        .attr("name", d => d.properties.name)
        .attr("id", d => d.id)
        .call(this.drag(simulation))
        // .on("click", nodeClick)
        .on('click', function (event) {
          // console.dir(this)
          const node = d3.select(this)
          let nodeClass = node.attr("class")
          if (nodeClass === 'inactive') {
            return
          }
          // node.attr("class", "fixed")
          // node.classed("fixed", true)
          // console.log(node)
          //获取被选中元素的名字
          let name = node.attr("name")
          let id = node.attr("id")
          let color = node.attr('fill')
          // console.log(name, id, color)
          //设置#info h4样式的颜色为该节点的颜色，文本为该节点name
          _this.$set(_this.selectNodeData, 'id', id)
          _this.$set(_this.selectNodeData, 'name', name)
          _this.$set(_this.selectNodeData, 'color', color)

          //遍历查找id对应的属性
          for (let item of _this.nodes) {
            if (item.id == id) {
              // for(var key in item.properties)
              _this.$set(_this.selectNodeData, 'properties', item.properties)
            }
          }
          // 遍历节点，并调整图的样式
          if (nodeClass !== 'active' && nodeClass !== 'fixed')
            _this.changeGraphStyle(name)
        })
        .on('mouseenter', function (event) {
          // console.dir(this)
          const node = d3.select(this)
          let nodeClass = node.attr("class")
          if (nodeClass === 'inactive') {
            return
          }
          // node.attr("class", "fixed")
          // node.classed("fixed", true)
          // console.log(node)
          //获取被选中元素的名字
          let name = node.attr("name")
          let id = node.attr("id")
          let color = node.attr('fill')
          // console.log(name, id, color)
          //设置#info h4样式的颜色为该节点的颜色，文本为该节点name
          _this.$set(_this.selectNodeData, 'id', id)
          // _this.$set(_this.selectNodeData, 'name', name)
          // _this.$set(_this.selectNodeData, 'color', color)
          // 遍历节点，并调整图的样式
          if (nodeClass !== 'active' && nodeClass !== 'fixed')
            _this.changeGraphStyle(name)
        })
        .on('mouseleave', event => {
          console.log(this.isNodeClicked)
          if (!this.isNodeClicked) {
            this.clearGraphStyle()
            // 如果此时有搜索关键字，则鼠标离开时保留原搜索选中的节点
            if (this.keywords !== '') {
              this.searchKeyWords()
            }
          }
        })
        .on('contextmenu', d3.contextMenu(this.menu))
      // .on('contextmenu', function (d, i) {
      //   // 阻止默认右键菜单的弹出
      //   d3.event.preventDefault()

      // })
      // .call(d3.drag()
      //   .on("start", dragstarted)
      //   .on("drag", dragged)
      //   .on("end", dragended)
      // )

      // 显示所有的文本
      // 设置大小、填充颜色、名字、text()设置文本
      // 使用 attr("text-anchor", "middle")设置文本居中
      var text = svg.append("g")
        .attr("class", "texts")
        .selectAll("text")
        .data(this.nodes)
        .enter()
        .append("text").attr("font-size", () => 13)
        .attr("fill", () => '#fff')
        .attr('name', d => d.properties.name)
        .attr("text-anchor", "middle")
        .attr('x', function (d) {
          return textBreaking(d3.select(this), d.properties.name)
        })
        .call(this.drag(simulation))
        // .on("click", nodeClick)
        .on('click', function (event) {

          // console.dir(this)
          const text = d3.select(this)
          // console.log(text)
          // 获取被选中元素的名字
          let name = text.attr("name")
          _this.$set(_this.selectNodeData, 'name', name)
          let textClass = text.attr("class")
          if (textClass === 'inactive') {
            return
          }
          // 根据文本名称获取节点的id
          for (let item of _this.nodes) {
            if (item.properties.name == name) {
              // 设置节点id和标签属性
              _this.$set(_this.selectNodeData, 'id', item.id)
              _this.$set(_this.selectNodeData, 'properties', item.properties)
              // 根据节点类型label获取节点颜色
              let index = 0
              while ((item.label) !== _this.labels[index]) {
                ++index;
                if (index > _this.labels.length)
                  break
              }
              console.log(index)
              _this.$set(_this.selectNodeData, 'color', _this.colors[index])
            }
          }
          console.log(textClass)
          if (textClass !== 'active' && textClass !== 'fixed')
            _this.changeGraphStyle(name)
        })
        .on('mouseenter', function (event) {

          // console.dir(this)
          const text = d3.select(this)
          // console.log(text)
          // 获取被选中元素的名字
          let name = text.attr("name")
          // _this.$set(_this.selectNodeData, 'name', name)
          let textClass = text.attr("class")
          if (textClass === 'inactive') {
            return
          }
          // 根据文本名称获取节点的id
          // for (let item of _this.nodes) {
          //   if (item.properties.name == name) {
          //     // 设置节点id和标签属性
          //     _this.$set(_this.selectNodeData, 'id', item.id)
          //     _this.$set(_this.selectNodeData, 'properties', item.properties)
          //     // 根据节点类型label获取节点颜色
          //     let index = 0
          //     while ((item.label) !== _this.labels[index]) {
          //       ++index;
          //       if (index > _this.labels.length)
          //         break
          //     }
          //     console.log(index)
          //     _this.$set(_this.selectNodeData, 'color', _this.colors[index])
          //   }
          // }
          console.log(textClass)
          if (textClass !== 'active' && textClass !== 'fixed')
            _this.changeGraphStyle(name)
        })
        .on('mouseleave', (event) => {
          if (!this.isNodeClicked) {
            this.clearGraphStyle()
            // 如果此时有搜索关键字，则鼠标离开时保留原搜索选中的节点
            if (this.keywords !== '') {
              this.searchKeyWords()
            }
          }
        })
        .on('contextmenu', d3.contextMenu(this.menu))
      // .call(d3.drag()
      //   .on("start", dragstarted)
      //   .on("drag", dragged)
      //   .on("end", dragended)
      // )

      // 圆增加title
      node.append("title").text(d => d.properties.name)

      // simulation中ticked数据初始化并生成图形
      simulation.on("tick", ticked)

      simulation.force("link")
        .links(this.links)
        .distance(d => { // 每一边的长度
          let distance = 20
          switch (d.source.label) {
            case _this.labels[0]:
              distance += 30;
              break;
            case _this.labels[1]:
              distance += 25;
              break;
            case _this.labels[2]:
              distance += 22;
              break;
            default:
              distance += 20;
              break;
          }
          switch (d.target.label) {
            case _this.labels[0]:
              distance += 30;
              break;
            case _this.labels[1]:
              distance += 25;
              break;
            case _this.labels[2]:
              distance += 22;
              break;
            default:
              distance += 20;
              break;
          }
          return distance * 2
        })

      /******************************************
       * 内部功能函数
       * 包括：ticked、文本分隔、节点和文本的点击事件
       */
      // ticked()函数确定link线的起始点x、y坐标 node确定中心点 文本通过translate平移变化
      function ticked() {
        link
          .attr("x1", d => d.source.x)
          .attr("y1", d => d.source.y)
          .attr("x2", d => d.target.x)
          .attr("y2", d => d.target.y)

        linksName
          .attr('transform', d => {
            let x = Math.min(d.source.x, d.target.x) + Math.abs(d.source.x - d.target.x) / 2
            let y = Math.min(d.source.y, d.target.y) + Math.abs(d.source.y - d.target.y) / 2 - 1
            // tanA = a / b
            // A = arctan(tanA)
            let tanA = Math.abs(d.source.y - d.target.y) / Math.abs(d.source.x - d.target.x)
            let angle = Math.atan(tanA) / Math.PI * 180
            // let angle = Math.atan2(1,1)/Math.PI*180
            // console.log(angle)
            // 第一、二象限额外处理
            if (d.source.x > d.target.x) {
              // 第二象限
              if (d.source.y <= d.target.y) {
                angle = -angle
              }
              // else {  // 第三象限
              //   angle = angle
              // }
            } else if (d.source.y > d.target.y) {
              // 第一象限
              angle = -angle
            }
            return 'translate(' + x + ',' + y + ')' + 'rotate(' + angle + ')'
          })

        node
          .attr("cx", d => d.x)
          .attr("cy", d => d.y)

        text.attr('transform', function (d) {
          let size = 15
          switch (d.label) {
            case _this.labels[0]:
              break;
            case _this.labels[1]:
              size = 14;
              break;
            case _this.labels[2]:
              size = 13;
              break;
            default:
              size = 12;
              break;
          }
          size -= 5
          return 'translate(' + (d.x - size / 2 + 3) + ',' + (d.y + size / 2) + ')'
        })
      }

      /**
       * 文本分隔（根据字数在当前选择器中分隔三行，超过10字省略）
       * @method textBreaking
       * @param {d3text} 文本对应的DOM对象
       * @param {text} 节点名称的文本值
       * @return {void}
       */
      function textBreaking(d3text, text) {
        const len = text.length
        if (len <= 5) {
          d3text.append('tspan')
            .attr('x', 0)
            .attr('y', 2)
            .text(text)
        } else {
          const topText = text.substring(0, 3)
          const midText = text.substring(3, 7)
          let botText = text.substring(7, len)
          let topY = -16
          let midY = 0
          let botY = 16
          if (len <= 7) {
            topY += 10
            midY += 10
          } else if (len > 10) {
            botText = text.substring(7, 9) + '...'
          }

          d3text.text('')
          d3text.append('tspan')
            .attr('x', 0)
            .attr('y', topY)
            .text(function () {
              return topText
            })
          d3text.append('tspan')
            .attr('x', 0)
            .attr('y', midY)
            .text(function () {
              return midText
            })
          d3text.append('tspan')
            .attr('x', 0)
            .attr('y', botY)
            .text(function () {
              return botText
            })
        }
      }

      // 分别定义节点和文本的点击事件
      // 优化：由于点击前必定触发mouseenter事件，所以不用再去查找节点id
      //      直接根据this.selectNodeData拿到节点信息
      // 优化后：只需定义一个点击事件即可
      function nodeClick(event, d) {
        // console.log('node clicked!')
        // sticked用于固定节点（无法实现节点固定功能）
        // delete d.fx
        // delete d.fy
        // d3.select(this).classed("fixed", true)
        // simulation.alpha(1).restart()

        // 获取被选中元素信息
        // const node = d3.select(this)
        // let name = node.attr("name")
        // let id = node.attr("id")
        // let color = node.attr('fill')
        // console.log(name, id, color)

        // 直接通过this.selectNodeData拿到节点信息
        event.cancelBubble = true
        event.stopPropagation() // 阻止事件冒泡

        const name = _this.selectNodeData.name
        _this.isNodeClicked = true
        _this.changeGraphStyle(name)

        return false
      }
    },
    // 根据当前节点名称来更改图样式
    changeGraphStyle(name) {
      // console.log(this.isNodeClicked)
      // 选择#svg1 .nodes中所有的circle，再增加个class
      this.svgDom.select('.nodes').selectAll('circle').attr('class', d => {
        // 节点属性name是否等于name，返回fixed（激活选中样式）
        if (d.properties.name == name) {
          return 'fixed'
        }
        // 当前节点返回空，否则其他节点循环判断是否被隐藏起来(CSS设置隐藏)
        else {
          // links链接的起始节点进行判断,如果其id等于name则显示这类节点
          // 注意: graph = data
          for (var i = 0; i < this.links.length; i++) {
            // 如果links的起点等于name，并且终点等于正在处理的则显示
            if (this.links[i]['source'].properties.name == name && this.links[i]['target'].id == d.id) {
              return 'active'
            }
            if (this.links[i]['target'].properties.name == name && this.links[i]['source'].id == d.id) {
              return 'active'
            }
          }
          return this.isNodeClicked ? 'inactive' : ''
        }
      })
      // 处理相邻的文字是否隐藏
      this.svgDom.select('.texts').selectAll('text')
        .attr('class', d => {
          // 节点属性name是否等于name，返回fixed（激活选中样式）
          if (d.properties.name == name) {
            return ''
          }
          // 当前节点返回空，否则其他节点循环判断是否被隐藏起来(CSS设置隐藏)
          else {
            // links链接的起始节点进行判断,如果其id等于name则显示这类节点
            // 注意: graph = data
            for (var i = 0; i < this.links.length; i++) {
              // 如果links的起点等于name，并且终点等于正在处理的则显示
              if (this.links[i]['source'].properties.name == name && this.links[i]['target'].id == d.id) {
                return ''
              }
              if (this.links[i]['target'].properties.name == name && this.links[i]['source'].id == d.id) {
                return ''
              }
            }
            return this.isNodeClicked ? 'inactive' : ''
          }
        })
      // 处理相邻的边line是否隐藏 注意 ||
      this.svgDom.select(".links").selectAll('line')
        .attr('class', d => {
          if (d.source.properties.name == name || d.target.properties.name == name) {
            return 'active'
          } else {
            return this.isNodeClicked ? 'inactive' : ''
          }
        })
        .attr('marker-end', d => {
          if (d.source.properties.name == name || d.target.properties.name == name) {
            return 'url(#posActMarker)'
          } else {
            return 'url(#posMarker)'
          }
        })
      // 处理相邻的边上文字是否隐藏 注意 ||
      this.svgDom.select(".linkTexts").selectAll('text')
        .attr('class', d => {
          if (d.source.properties.name == name || d.target.properties.name == name) {
            return 'active'
          } else {
            return this.isNodeClicked ? 'inactive' : ''
          }
        })
    },
    clearGraphStyle() {
      // 移除所有样式
      this.svgDom.select('.nodes').selectAll('circle').attr('class', '')
      this.svgDom.select(".texts").selectAll('text').attr('class', '')
      this.svgDom.select('.links').selectAll('line').attr('class', '').attr('marker-end', 'url(#posMarker)')
      this.svgDom.select(".linkTexts").selectAll('text').attr('class', '')
      // d3.select(this).attr('class', '')
    },
    drag(simulation) {
      function dragsubject(event) {
        return simulation.find(event.x, event.y);
      }

      function dragstarted(event) {
        if (!event.active) simulation.alphaTarget(0.3).restart();
        event.subject.fx = event.subject.x;
        event.subject.fy = event.subject.y;
      }

      function dragged(event) {
        event.subject.fx = event.x;
        event.subject.fy = event.y;
      }

      function dragended(event) {
        if (!event.active) simulation.alphaTarget(0);
        // 注释以下代码，使拖动结束后固定节点
        // event.subject.fx = null;
        // event.subject.fy = null;
      }

      return d3.drag()
        .subject(dragsubject)
        .on("start", dragstarted)
        .on("drag", dragged)
        .on("end", dragended)
    },
    // 绘制关系箭头
    addMarkers() {
      // 定义箭头的标识
      var defs = this.svgDom.append("defs")
      //未点击时箭头
      const posMarker = defs.append("marker")
        .attr("id", "posMarker")
        .attr("orient", "auto")
        .attr("stroke-width", 2)
        .attr("markerUnits", "strokeWidth")
        .attr("markerUnits", "userSpaceOnUse")
        .attr("viewBox", "0 -5 10 10")
        .attr("refX", 31)
        .attr("refY", 0)
        .attr("markerWidth", 12)
        .attr("markerHeight", 12)
        .append("path")
        .attr("d", "M 0 -5 L 10 0 L 0 5")
        .attr('fill', '#5399ed')
        .attr("stroke-opacity", 0.6);
      //点击后箭头
      const posActMarker = defs.append("marker")
        .attr("id", "posActMarker")
        .attr("orient", "auto")
        .attr("stroke-width", 2)
        .attr("markerUnits", "strokeWidth")
        .attr("markerUnits", "userSpaceOnUse")
        .attr("viewBox", "0 -5 10 10")
        .attr("refX", 31)
        .attr("refY", 0)
        .attr("markerWidth", 12)
        .attr("markerHeight", 12)
        .append("path")
        .attr("d", "M 0 -5 L 10 0 L 0 5")
        .attr('fill', '#1E90FF')
        .attr("stroke-opacity", 0.6);
    }
  }
}
</script>

<style lang="scss">
@import '@/plugins/d3-context-menu';

$opacity: 0; /* 显示的不透明度 */
$activeColor: #1E90FF; /* 激活的颜色 */
.policyFont {
  margin-right: 10px;
  font-weight: 530;
}

.el-button--primary {
  color: #FFF;
  background: #1e456b;
  height: 50px;
  font-size: 20px;
  font-family: 等线;
  font-weight: 550;
}

.el-button--primary.is-active,
.el-button--primary:active {
  background: #000000;
  border-color: #000000;
  color: #fff;
}

.el-button--primary:focus,
.el-button--primary:hover {
  background: #1e456b;
  border-color: #1e456b;
  color: #fff;
}

.el-select {
  display: inline-block;
  position: relative;
  width: 130px;
}


.el-input--medium .el-input__inner {
  height: 50px;
  font-size: 20px;
}

.el-button--primary {
  color: #FFF;
  background-color: #1e456b;
  border-color: #1e456b;
  height: 50px;
  font-size: 20px;
  font-family: 等线;
  font-weight: 550;
}

::v-deep .el-input__inner {
  font-weight: bold;
  font-size: 20px;
  border: 2px solid #a6a6a6;
}

::v-deep .el-button--medium {
  padding: 10px 20px;
  border-radius: 13px;
}

.search {
  display: inline-block;
}

.el-button--default {
  color: #FFF;
  background-color: #2a56bb;
  border-color: #2a56bb;
  height: 50px;
  font-size: 20px;
  font-family: 等线;
  font-weight: 550;
}

.search-bar {
  width: 80%;
  display: inline-block;
  background-color: #ffffff;
  margin-top: 20px;
  -webkit-box-shadow: #666 0 0 0.1rem;
  -moz-box-shadow: #666 0 0 0.1rem;
  box-shadow: #666 0 0 0.1rem;
}

/*设置节点及边的样式*/
.links line {
  stroke: #5399ed; // #bbb
  stroke-opacity: 1;

  &.inactive {
    /* display: none !important; */
    opacity: $opacity;
  }

  &.active {
    stroke: $activeColor;
    stroke-width: 3px;
  }

  &.hide {
    display: none !important;
  }
}

.nodes circle {
  // stroke: #000;
  // stroke-width: 1.5px;
  &.fixed {
    // fill: rgb(102, 81, 81);
    stroke: #FFC0CB; // #888;
    stroke-width: 14px;
    stroke-opacity: $opacity + 0.3;
    border: 10px #000 solid;
  }

  &.inactive {
    /* display: none !important; */
    opacity: $opacity;
  }

  &.active {
    stroke: $activeColor;
    stroke-width: 4px;
  }

  &:hover {
    cursor: pointer;
  }

  &.hide {
    display: none !important;
  }
}

.texts text {
  cursor: pointer;
  text-decoration: none;
  user-select: none;

  &:hover {
    cursor: pointer;
  }

  &.inactive {
    /* display: none !important; */
    opacity: $opacity;
  }
}

.linkTexts text {
  stroke: #78a1fc; // #bbb
  stroke-opacity: 1;

  &.active {
    stroke: $activeColor;
  }

  &.inactive {
    /* display: none !important; */
    opacity: $opacity;
  }
}

// #positiveMarker path {
//   fill: #fff;
// }
</style>
<style lang="scss" scoped>
@media only screen and (max-width: 1125px) {
  #info, #mode {
    display: none !important;
  }
}

.el-col-7 {
  width: 240px;
  padding-left: 0px;
  padding-right: 0px;
}

.font-sky {
  font-size: 18px;
  color: #034c6a !important;
}

#indicator {
  position: fixed;
  // left: 50px;
  // bottom: 30px;
  left: var(--indicator_left);
  top: var(--indicator_top);
  text-align: left;
  color: #f2f2f2;
  font-size: 14px;
  font-weight: bold;

  & > div {
    margin-bottom: 4px;
  }

  span {
    display: inline-block;
    width: 32px;
    height: 16px;
    position: relative;
    top: 2px;
    margin-right: 8px;
  }
}

/*mode选项样式*/
#mode {
  position: absolute;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-start;
  top: 200px;
  left: 40px;

  .gState span {
    display: inline-block;
    border: 1px solid #fff;
    color: #fff;
    padding: 6px 10px;
    border-radius: 4px;
    font-size: 14px;
    transition: color, background-color .3s;
    -o-transition: color, background-color .3s;
    -ms-transition: color, background-color .3s;
    -moz-transition: color, background-color .3s;
    -webkit-transition: color, background-color .3s;

    ~ .active, ~ :hover {
      background-color: #fff;
      color: #333;
      cursor: pointer;
    }
  }

  .gState span.active, .gState span:hover {
    background-color: #fff;
    color: #333;
    cursor: pointer;
  }
}

svg {
  background-color: #ffffff;
  filter: progid:DXImageTransform.Microsoft.Shadow(color=#909090, direction=120, strength=4);
  -webkit-box-shadow: #666 0 0 0.1rem;
  -moz-box-shadow: #666 0 0 0.1rem;
  box-shadow: #666 0 0 0.1rem;
  margin-top: 30px;
}

/*悬浮节点的info样式*/
#info {
  position: fixed;
  top: var(--info_top);
  right: 14%;
  width: 300px;

  .node-card {
    border: 1px solid #9faecf;
    background-color: #00aeff6b;
    color: #fff;
    text-align: left;
    // transition: background-color;
    // transition-delay: .3s;
    // transition-timing-function: ease;
    .el-card__header {
      border-bottom: 1px solid #50596d;
    }

    ::v-deep .el-card__body, {
      padding: 20px;
      overflow-y: auto;
      max-height: 400px
    }

    ::v-deep .el-card__body::-webkit-scrollbar {
      width: 8px;
      height: 4px;
    }

    ::v-deep .el-card__body::-webkit-scrollbar-thumb {
      border-radius: 3px;
      box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
      background: #c7c4c4;
    }

    ::v-deep .el-card__body::-webkit-scrollbar-track {
      box-shadow: 1px 1px 5px rgba(0, 0, 0, 0.2) inset;
    }

    ::v-deep .el-card__body::-webkit-scrollbar-corner {
      background: transparent;
    }
  }
}
</style>
