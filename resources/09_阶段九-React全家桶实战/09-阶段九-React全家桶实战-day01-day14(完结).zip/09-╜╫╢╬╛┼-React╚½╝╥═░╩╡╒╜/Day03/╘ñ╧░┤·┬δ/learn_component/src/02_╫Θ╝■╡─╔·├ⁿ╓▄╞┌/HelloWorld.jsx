import React, { Component } from 'react'

class HelloWorld extends Component {
  componentWillUnmount() {
    console.log("HelloWorld componentWillUnmount")
  }

  render() {
    return (
      <div>HelloWorld</div>
    )
  }
}

export default HelloWorld