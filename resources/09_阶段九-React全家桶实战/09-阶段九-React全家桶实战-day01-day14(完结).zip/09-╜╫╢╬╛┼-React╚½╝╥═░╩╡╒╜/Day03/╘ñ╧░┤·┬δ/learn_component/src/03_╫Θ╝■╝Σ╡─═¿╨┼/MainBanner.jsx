import React, { Component } from 'react'

export class MainBanner extends Component {
  render() {
    return (
      <div>MainBanner</div>
    )
  }
}

export default MainBanner