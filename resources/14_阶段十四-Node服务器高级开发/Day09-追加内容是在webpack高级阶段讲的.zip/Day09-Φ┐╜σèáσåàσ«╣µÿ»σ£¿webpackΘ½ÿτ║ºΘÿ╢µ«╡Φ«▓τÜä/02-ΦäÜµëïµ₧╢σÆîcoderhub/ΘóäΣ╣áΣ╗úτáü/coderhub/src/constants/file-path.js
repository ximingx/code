const AVATAR_PATH = './upload/avatar'

module.exports = {
  AVATAR_PATH
}
