<template>
  <div class="overview">overview</div>
</template>

<script setup lang="ts" name="overview"></script>

<style scoped lang="less">
.overview {
}
</style>
