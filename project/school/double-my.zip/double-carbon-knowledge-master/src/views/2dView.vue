<template>
  <div class="gContainer">
    <gSearch @getData="update" />
    <d3graph
      :data="data"
      :names="names"
      :labels="labels"
      :linkTypes="linkTypes"
    />
  </div>
</template>

<script>
import gSearch from '@/components/gSearch.vue'
import d3graph from '@/components/d3graph.vue'
export default {
  components: {
    gSearch,
    d3graph
  },
  data () {
    return {
      data: {
        nodes: [],
        links: []
      },
      // names: ['发布年份', '发布人', '政策来源', '政策名称', '政策类型', '政策概况'],
      // labels: ['doc_year', 'doc_author', 'doc_source', 'doc', 'doc_type', 'doc_url'],
      names: ["患病名称", "简介", "发病部位", "相关症状", "治疗周期", "治愈率"],
      labels: ['disease_name', 'intro', 'pathogenic_site', 'correlation', 'treatment_cycle', 'cure_rate'],
      linkTypes: ['']
    }
  },
  methods: {
    update (json) {
      this.d3jsonParser(json)
    },
    d3jsonParser (json) {
      const nodes =[]
      const links = [] // 存放节点和关系
      const nodeSet = [] // 存放去重后nodes的id

      // 使用vue直接通过require获取本地json，不再需要使用d3.json获取数据
      // d3.json('./../data/records.json', function (error, data) {
      //   if (error) throw error
      //   graph = data
      //   console.log(graph[0].p)
      // })

      for (let item of json) {
        for (let segment of item.p.segments) {
          // 重新更改data格式
          if (nodeSet.indexOf(segment.start.identity) == -1) {
            nodeSet.push(segment.start.identity)
            nodes.push({
              id: segment.start.identity,
              label: segment.start.labels[0],
              properties: segment.start.properties
            })
          }
          if (nodeSet.indexOf(segment.end.identity) == -1) {
            nodeSet.push(segment.end.identity)
            nodes.push({
              id: segment.end.identity,
              label: segment.end.labels[0],
              properties: segment.end.properties
            })
          }
          links.push({
            source: segment.relationship.start,
            target: segment.relationship.end,
            type: segment.relationship.type,
            properties: segment.relationship.properties
          })
        }
      }
      this.data = { nodes, links }
      let fullscreenLoading = false
      this.$events.$emit('setfullscreenLoading',fullscreenLoading)
    }
  }
}
</script>

<style lang="scss" scoped>
.gContainer {
  position: relative;
  border: 2px #000 solid;
  background-color: #f4f7fa;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  height: 100%;
}
</style>
