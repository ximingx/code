import React, { PureComponent } from 'react'
import store from "./store"
import { addNumberAction, subNumberAction } from "./store"

import Home from "./pages/Home"

export class App extends PureComponent {
  constructor(props) {
    super(props)

    this.state = {
      counter: store.getState().counter
    }
  }

  componentDidMount() {
    this.unsubscribe = store.subscribe(() => {
      const state = store.getState()
      this.setState({ counter: state.counter })
    })
  }

  componentWillUnmount() {
    this.unsubscribe()
  }

  addNumber(count) {
    store.dispatch(addNumberAction(count))
  }

  subNumber(count) {
    store.dispatch(subNumberAction(count))
  }

  render() {
    const { counter } = this.state

    return (
      <div>
        <h2>App Counter: {counter}</h2>
        <button onClick={e => this.addNumber(1)}>+1</button>
        <button onClick={e => this.addNumber(5)}>+5</button>
        <button onClick={e => this.subNumber(1)}>-1</button>
        <button onClick={e => this.subNumber(5)}>-5</button>

        <Home/>
      </div>
    )
  }
}

export default App
