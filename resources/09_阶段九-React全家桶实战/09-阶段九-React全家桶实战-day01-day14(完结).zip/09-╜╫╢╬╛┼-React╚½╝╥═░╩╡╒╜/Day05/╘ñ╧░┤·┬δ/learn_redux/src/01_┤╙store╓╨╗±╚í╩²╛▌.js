const store = require("./store")

console.log('获取数据~')
console.log(store.getState())
