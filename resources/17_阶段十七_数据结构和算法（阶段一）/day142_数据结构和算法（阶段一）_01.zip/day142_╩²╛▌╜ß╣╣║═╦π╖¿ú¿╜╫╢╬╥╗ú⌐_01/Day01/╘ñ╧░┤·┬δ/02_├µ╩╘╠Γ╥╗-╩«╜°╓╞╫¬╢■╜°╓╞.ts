import ArrayStack from "./01_实现Stack";

function decimalToBinary(decimal: number): string {
  const stack = new ArrayStack()

  let remainder = 0
  while (decimal > 0) {
    remainder =  decimal % 2
    stack.push(remainder)
    decimal = Math.floor(decimal / 2)
  }

  let binary = ""
  while (!stack.isEmpty()) {
    binary += stack.pop()
  }
  return binary
}

console.log(decimalToBinary(35))

export {}
