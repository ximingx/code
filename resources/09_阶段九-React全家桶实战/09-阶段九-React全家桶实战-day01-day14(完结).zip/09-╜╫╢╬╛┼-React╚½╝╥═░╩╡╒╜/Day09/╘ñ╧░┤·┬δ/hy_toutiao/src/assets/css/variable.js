export const mainColor = "#333"
export const mainActiveColor = "#f04142"