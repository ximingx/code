class Node<T> {
  constructor(
    public value: T, 
    public next: Node<T> | null = null
  ) {}
}


class LinkedList<T> {
  private head: Node<T> | null = null
  private size: number = 0

  // 实现方法
  append(value: T) {
    const newNode = new Node(value)
    if (!this.head) {
      this.head = newNode
    } else {
      let current = this.head
      while (current.next) {
        current = current.next
      }
      current.next = newNode
    }
    this.size++
  }

  // 任意位置插入元素
  insert(value: T, position: number): boolean {
    if (position < 0 || position > this.size) return false

    // 创建新节点
    const newNode = new Node(value)
    if (position === 0) {
      newNode.next = this.head
      this.head = newNode
    } else {
      let index = 0
      let previous: Node<T> | null = null
      let current = this.head
      while (index++ < position && current) {
        previous = current
        current = current.next
      }

      previous!.next = newNode
      newNode.next = current
    }

    this.size++
    return true
  }

  // 删除方法
  removeAt(position: number): T | null {
    if (position < 0 || position >= this.size) return null
    let current = this.head
    if (position === 0) {
      this.head = this.head?.next ?? null
    } else {
      let i = 0
      let previous: Node<T> | null = null
      while (i++ < position && current) {
        previous = current
        current = current.next
      }

      previous!.next = current?.next ?? null
    }
    this.size--
    return current?.value ?? null
  }

  // 根据索引获取元素
  get(position: number): T | null {
    if (position < 0 || position >= this.size) return null
    let index = 0
    let current = this.head
    while (index++ < position && current) {
      current = current.next
    }
    return current?.value ?? null
  }

  // 遍历链表
  traverse() {
    const values: T[] = []
    let current = this.head
    while (current) {
      values.push(current.value)
      current = current.next
    }
    console.log(values.join('->'))
  }

  // 私有方法
  private getNode(position: number): Node<T> | null {
    let index = 0
    let current = this.head
    while (index++ < position && current) {
      current = current.next
    }
    return current
  }
}

const linkedList = new LinkedList<string>()
linkedList.append("aaa")
linkedList.append("bbb")
linkedList.append("ccc")

linkedList.insert("abc", 2)
linkedList.insert("cba", 1)
linkedList.insert("nba", 0)
linkedList.insert("mba", 6)

linkedList.traverse()

linkedList.removeAt(3)
linkedList.removeAt(0)
linkedList.removeAt(4)
linkedList.traverse()

console.log(linkedList.get(0))
console.log(linkedList.get(2))
console.log(linkedList.get(3))

export {}
