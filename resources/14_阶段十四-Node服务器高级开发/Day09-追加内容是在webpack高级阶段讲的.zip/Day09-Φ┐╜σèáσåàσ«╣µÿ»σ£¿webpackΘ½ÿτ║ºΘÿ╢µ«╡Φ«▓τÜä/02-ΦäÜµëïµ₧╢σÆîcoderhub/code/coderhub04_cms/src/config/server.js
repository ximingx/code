const dotenv = require('dotenv')

dotenv.config()

module.exports = {
  SERVER_PORT,
  SERVER_HOST
} = process.env
