class Node<T> {
  value: T
  constructor(value: T) {
    this.value = value
  }
}

export default Node
