import styled from 'styled-components'

export const AppContent = styled.div`
  display: flex;
  justify-content: space-between;

  width: 1066px;
  margin: 0 auto;
`