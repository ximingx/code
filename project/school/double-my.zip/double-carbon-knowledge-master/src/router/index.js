import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/2dView.vue'
import NotFound from '../views/404'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home,
    meta:{
      // 页面标题title
      title: '病虫害知识图谱'
    }
  },{
    path: '/404',
    name: 'notFound',
    component: NotFound,
    meta:{
      // 页面标题title
      title: '404资源未找到'
    }
  }
]

const router = new VueRouter({
  routes
})

export default router
