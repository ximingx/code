function hashFunc(str: string, max: number): number {
  // 1.初始化hashCode
  let hashCode = 0

  // 2.霍纳算法, 计算hashCode的值
  for (let i = 0; i < str.length; i++) {
    hashCode = 31 * hashCode + str.charCodeAt(i)
  }

  // 3.通过取模计算索引值
  return hashCode % max
}

export {}

