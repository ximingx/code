<template>
  <div class="dashboard">dashboard</div>
</template>

<script setup lang="ts" name="dashboard"></script>

<style scoped lang="less">
.dashboard {
}
</style>
