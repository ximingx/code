import React, { useEffect, useState } from 'react'

function App() {
  const [ count, setCount ] = useState(0)

  useEffect((cCount = count) => {
    console.log("在组件被渲染完成:", cCount)
    document.title = "当前计数" + cCount

    return () => {
      console.log("被移除时执行~")
    }
  }, [count])

  useEffect(() => {
    console.log("useEffect02")
  }, [])

  return (
    <div>
      <h2>当前计数: {count}</h2>
      <button onClick={e => setCount(count+1)}>+1</button>
      <button onClick={e => setCount(count-1)}>-1</button>
    </div>
  )
}

export default App