import styled from "styled-components";

export const HouseWrapper = styled.div`
  display: flex;
  padding: 40px 20px;
  flex-wrap: wrap;
`