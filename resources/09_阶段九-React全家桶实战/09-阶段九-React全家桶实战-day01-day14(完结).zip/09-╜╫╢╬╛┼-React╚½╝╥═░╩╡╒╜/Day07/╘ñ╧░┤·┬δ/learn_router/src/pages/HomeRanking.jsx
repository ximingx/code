import React, { PureComponent } from 'react'

export class HomeRanking extends PureComponent {
  render() {
    return (
      <div>
        <h2>Home Ranking</h2>
        <ul>
          <li>排行榜歌单1</li>
          <li>排行榜歌单2</li>
          <li>排行榜歌单3</li>
          <li>排行榜歌单4</li>
          <li>排行榜歌单5</li>
        </ul>
      </div>
    )
  }
}

export default HomeRanking