import styled from 'styled-components'

export const HotVideosWrapper = styled.div`
  margin-top: 50px;
`
