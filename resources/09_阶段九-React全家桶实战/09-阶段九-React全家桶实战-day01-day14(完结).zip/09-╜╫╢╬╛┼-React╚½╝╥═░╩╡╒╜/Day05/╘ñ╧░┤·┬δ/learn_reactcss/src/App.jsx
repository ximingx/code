/** @jsxImportSource @emotion/react */

import "./01_css/App.css"
import "./02_less/App.less"
import Home from "./Home";
import titleStyle from "./03_module/title.module.css"
import contentStyle from "./03_module/content.module.less"
import { FiveWrapper } from "./04_emotion/style"

import { css } from "@emotion/react";

function App() {
  return (
    <div className="app">
      {/* 1.普通的CSS */}
      <div className="one">
        <h2 className="title">普通CSS方式</h2>
        <p className="content">我是普通的CSS方式的内容</p>
      </div>

      {/* 2.less的写法 */}
      <div className="two">
        <h2 className="title">LESS方式</h2>
        <p className="content">我是LESS的内容</p>
      </div>

      {/* 3. CSS Module */}
      <div className={contentStyle.three}>
        <div className={titleStyle.title}>CSS Module方式</div>
        <div className={contentStyle.content}>我是CSS Module的内容</div>
      </div>

      {/* 4.emotion react */}
      <div css={
        css`
          border: 1px solid orange;
        `
      }>
        <div css={css`font-size: 30px; color: red;`}>@emotion/react</div>
        <div css={css`font-size: 20px; color: green;`}>@emotion/react</div>
      </div>

      {/* 5.emotion style */}
      <FiveWrapper>
        <div className="title">emotion style</div>
        <div className="content">emotion style</div>
      </FiveWrapper>

      {/* 5.tailwindcss style */}
      <div className="border border-[#f00] border-solid">
        <div className="text-[30px] text-[blue]">tailwindcss style</div>
        <div className="text-[20px] text-[orange]">tailwindcss style</div>
      </div>
        
      <Home/>
    </div>
  );
}

export default App;
