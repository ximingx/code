<template>
  <div class="category">
    <h2>category</h2>
  </div>
</template>

<script setup lang="ts" name="category"></script>

<style scoped>
.category{
}
</style>
