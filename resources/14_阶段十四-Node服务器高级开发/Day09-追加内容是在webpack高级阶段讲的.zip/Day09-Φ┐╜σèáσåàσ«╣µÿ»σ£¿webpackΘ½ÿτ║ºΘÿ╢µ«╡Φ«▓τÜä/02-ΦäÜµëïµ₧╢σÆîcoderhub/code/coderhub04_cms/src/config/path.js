const UPLOAD_PATH = './uploads'

module.exports = {
  UPLOAD_PATH
}
