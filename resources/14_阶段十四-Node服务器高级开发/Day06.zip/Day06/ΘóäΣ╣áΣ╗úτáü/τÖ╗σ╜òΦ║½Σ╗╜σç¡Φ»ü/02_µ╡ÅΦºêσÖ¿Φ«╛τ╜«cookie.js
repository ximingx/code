const Koa = require('koa')
const KoaRouter = require('@koa/router')

const app = new Koa()

const userRouter = new KoaRouter({ prefix: '/users' })
userRouter.get('/test', (ctx, next) => {
  ctx.cookies.set('name', 'james', {
    maxAge: 60 * 1000
  })
  ctx.body = 'test data~'
})

userRouter.get('/demo', (ctx, next) => {
  console.log(ctx.cookies.get('name'))
  ctx.body = `demo data~`
})

app.use(userRouter.routes())
app.use(userRouter.allowedMethods())

app.listen(9000, () => {
  console.log('服务器启动成功~')
})
