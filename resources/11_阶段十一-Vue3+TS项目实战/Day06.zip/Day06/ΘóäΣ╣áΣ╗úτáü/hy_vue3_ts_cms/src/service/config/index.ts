export const BASE_URL1 = 'http://152.136.185.210:5000'
export const TIME_OUT1 = 10000
