import styled from "styled-components";

export const RoomWrapper = styled.div`
  display: flex;
  flex-wrap: wrap;
  margin: 0 -8px 0;
`