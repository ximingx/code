# Day11 作业布置

## 一. 完成课堂所有的代码练习





## 二. 说出常见的CSS Transform形变有哪些





### 补充: 说出transform/translate/transition分别的作用





## 三. 说出CSS Transition和Animation动画的区别





## 四. 理解vertical-align的作用和行盒的理解





## 五. 完成小米布局中的动画效果





## 六. 自己找一个包含动画的网页案例(比如考拉页面)



















