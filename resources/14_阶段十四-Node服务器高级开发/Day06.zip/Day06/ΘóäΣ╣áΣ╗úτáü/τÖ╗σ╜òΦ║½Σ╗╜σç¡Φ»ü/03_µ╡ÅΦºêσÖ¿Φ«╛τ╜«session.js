const Koa = require('koa')
const KoaRouter = require('@koa/router')
const Session = require('koa-session')

const app = new Koa()

const session = Session({
  key: 'sessionid',
  maxAge: 60 * 1000,
  signed: true
}, app)

app.keys = ['hahahah']
app.use(session)

const userRouter = new KoaRouter({ prefix: '/users' })
userRouter.get('/test', (ctx, next) => {
  ctx.session = { id: 110, name: 'why' }
  ctx.body = 'test data~'
})

userRouter.get('/demo', (ctx, next) => {
  console.log(ctx.session)
  ctx.body = `demo data~`
})

app.use(userRouter.routes())
app.use(userRouter.allowedMethods())

app.listen(9000, () => {
  console.log('服务器启动成功~')
})
