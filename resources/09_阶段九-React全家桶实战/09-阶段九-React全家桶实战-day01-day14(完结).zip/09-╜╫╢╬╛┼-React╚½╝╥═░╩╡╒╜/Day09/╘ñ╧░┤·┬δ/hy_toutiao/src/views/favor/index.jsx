import React, { memo } from 'react';

export default memo(function Home() {
  return (
    <div>Favor</div>
  )
})
