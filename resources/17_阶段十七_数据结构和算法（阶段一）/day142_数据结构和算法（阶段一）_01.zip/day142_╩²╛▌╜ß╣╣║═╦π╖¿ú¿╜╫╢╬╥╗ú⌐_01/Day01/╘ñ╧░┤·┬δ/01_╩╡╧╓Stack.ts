import { IStack } from "./stack";

class ArrayStack<T = number> implements IStack<T> {
  private data: T[] = []

  push(element: T) {
    this.data.push(element)
  }
  pop(): T | undefined {
    return this.data.pop()
  }
  peek(): T | undefined {
    return this.data[this.data.length - 1]
  }

  isEmpty(): boolean {
    return this.data.length === 0
  }

  get size(): number {
    return this.data.length
  }
}


export default ArrayStack
