import React, { PureComponent } from 'react'
import { Navigate } from 'react-router-dom'

export class Profile extends PureComponent {
  constructor(props) {
    super(props)

    this.state = {
      isLogin: false
    }
  }

  render() {
    const { isLogin } = this.state

    if (isLogin) {
      return <h2>Profile: coderwhy</h2>
    } else {
      return <Navigate to="/login"/>
    }
  }
}

export default Profile