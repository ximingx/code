import React, { PureComponent } from 'react'
import { Link, Outlet } from 'react-router-dom'
import withRouter from "../hooks/withRouter"

export class Home extends PureComponent {
  navigateTo(path) {
    const router = this.props.router
    router.navigate(path)
  }

  render() {
    return (
      <div>
        <h1>Home Page</h1>
        {/* <Link to="/home/recommend">推荐</Link>
        <Link to="/home/ranking">排行榜</Link> */}

        <button onClick={e => this.navigateTo("/home/recommend")}>推荐</button>
        <button onClick={e => this.navigateTo("/home/ranking")}>排行榜</button>

        <Outlet/>
      </div>
    )
  }
}

export default withRouter(Home)