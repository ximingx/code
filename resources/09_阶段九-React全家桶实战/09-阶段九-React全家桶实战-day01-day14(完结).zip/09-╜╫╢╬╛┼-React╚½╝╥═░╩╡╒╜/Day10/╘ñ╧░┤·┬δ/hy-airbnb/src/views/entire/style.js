import styled from "styled-components"

export const EntireWrapper = styled.div`
  margin-top: 128px;
`
