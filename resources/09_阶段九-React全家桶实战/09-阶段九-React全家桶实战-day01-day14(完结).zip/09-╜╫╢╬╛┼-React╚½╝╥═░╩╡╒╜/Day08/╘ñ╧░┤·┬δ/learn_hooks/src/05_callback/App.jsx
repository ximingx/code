import React, { memo, useCallback, useState } from 'react'


const Increment = memo(function(props) {
  console.log("Increment render")
  return <button onClick={props.add}>+1</button>
})

const Decrement = memo(function(props) {
  console.log("Decrement render")
  return <button onClick={props.sub}>-1</button>
})


function App() {
  const [count, setCount] = useState(0)

  const increment = useCallback(() => {
    setCount(count + 1)
  }, [count])

  const decrement = () => {
    setCount(count - 1)
  }

  return (
    <div>
      <h2>当前计数: {count}</h2>
      <Increment add={increment}/>
      <Decrement sub={decrement}/>
    </div>
  )
}

export default App