import React, { Component } from 'react'
import HelloWorld from './HelloWorld'

class App extends Component {
  constructor() {
    super()
    this.state = {
      message: "Hello World",
      isShowHW: true
    }
  }

  componentDidMount() {
    console.log("componentDidMount")
  }

  componentDidUpdate() {
    console.log("componentDidUpdate")
  }

  componentWillUnmount() {
    console.log("componentWillUnmount")
  }

  changeText() {
    this.setState({ message: "你好啊, 李银河!" })
  }

  switchHW() {
    this.setState({ isShowHW: !this.state.isShowHW })
  }

  render() {
    const {message, isShowHW} = this.state

    return (
      <div>
        <h2>{message}</h2>
        <button onClick={() => this.changeText()}>修改文本</button>

        <button onClick={() => this.switchHW()}>切换HelloWorld</button>
        { isShowHW && <HelloWorld/> }
      </div>
    )
  }
}

export default App