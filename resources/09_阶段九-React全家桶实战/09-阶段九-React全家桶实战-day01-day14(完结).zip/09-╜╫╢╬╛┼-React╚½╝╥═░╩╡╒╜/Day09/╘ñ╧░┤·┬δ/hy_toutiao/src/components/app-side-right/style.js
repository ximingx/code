import styled from 'styled-components'

export const AppRightWrapper = styled.div`
  width: 318px;
`
