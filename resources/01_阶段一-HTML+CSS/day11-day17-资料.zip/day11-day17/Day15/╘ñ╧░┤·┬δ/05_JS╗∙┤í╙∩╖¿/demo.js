
/**
 * 打招呼函数
 * @param {string} name 
 */
function sayHello(name) {
  console.log("Hello " + name)
}

sayHello()