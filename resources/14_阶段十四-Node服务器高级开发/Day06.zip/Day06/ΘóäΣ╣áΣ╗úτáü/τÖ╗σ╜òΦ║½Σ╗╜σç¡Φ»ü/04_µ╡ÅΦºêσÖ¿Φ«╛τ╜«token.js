const fs = require('fs')
const Koa = require('koa')
const KoaRouter = require('@koa/router')
const jwt = require('jsonwebtoken')

const app = new Koa()

// const SECRET_KEY = 'aaaabbbbccc123'
const PRIVATE_KEY = fs.readFileSync('./private.key')
const PUBLIC_KEY = fs.readFileSync('./public.key')

const userRouter = new KoaRouter({ prefix: '/users' })
userRouter.get('/test', (ctx, next) => {
  const token = jwt.sign({ id: 111, name: 'kobe' }, PRIVATE_KEY, {
    expiresIn: 10,
    algorithm: 'RS256'
  })
  ctx.body = token
})

userRouter.get('/demo', (ctx, next) => {
  const authorization = ctx.headers.authorization
  const token = authorization.replace('Bearer ', '')
  const user = jwt.verify(token, PUBLIC_KEY, {
    algorithms: ['RS256']
  })
  console.log(user)
  ctx.body = `demo data~`
})

app.use(userRouter.routes())
app.use(userRouter.allowedMethods())

app.listen(9000, () => {
  console.log('服务器启动成功~')
})
