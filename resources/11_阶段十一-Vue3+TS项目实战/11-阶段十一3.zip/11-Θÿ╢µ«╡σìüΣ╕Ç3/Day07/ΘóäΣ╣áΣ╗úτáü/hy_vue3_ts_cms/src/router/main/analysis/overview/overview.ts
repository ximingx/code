export default {
  path: '/main/analysis/overview',
  component: () => import('@/views/main/analysis/overview/overview.vue')
}
