import React, { useMemo } from 'react'

function App() {
  const result = useMemo(() => {
    
  }, [])

  return (
    <div>App: {result}</div>
  )
}

export default App