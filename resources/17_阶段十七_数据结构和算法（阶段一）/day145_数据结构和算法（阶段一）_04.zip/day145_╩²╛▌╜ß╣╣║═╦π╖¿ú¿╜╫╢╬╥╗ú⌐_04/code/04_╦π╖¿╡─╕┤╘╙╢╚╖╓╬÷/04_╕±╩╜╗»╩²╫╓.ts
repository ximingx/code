function formatPrice(price: number) {
  const priceStr = "¥" + price

  return priceStr
}