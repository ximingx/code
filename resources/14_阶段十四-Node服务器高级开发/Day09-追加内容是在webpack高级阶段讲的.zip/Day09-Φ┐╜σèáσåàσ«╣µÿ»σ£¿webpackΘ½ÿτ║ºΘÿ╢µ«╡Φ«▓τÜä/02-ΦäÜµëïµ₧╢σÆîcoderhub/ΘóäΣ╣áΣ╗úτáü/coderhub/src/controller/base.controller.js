class BaseController {
  create() {

  }

  remove() {}

  update() {}

  list() {}

  detail() {}
}

module.exports = BaseController
