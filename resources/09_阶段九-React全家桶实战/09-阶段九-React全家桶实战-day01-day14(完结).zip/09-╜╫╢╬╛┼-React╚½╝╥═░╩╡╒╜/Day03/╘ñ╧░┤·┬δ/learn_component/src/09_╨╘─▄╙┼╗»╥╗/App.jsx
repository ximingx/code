import React, { Component } from 'react'
import { flushSync } from "react-dom"
import HelloWorld from './HelloWorld'

export class App extends Component {
  constructor() {
    super()

    this.state = {
      message: "Hello World",
      counter: 0,
      friends: ["abc", "cba", "nba"]
    }
  }

  componentDidMount() {
    // this.setState({
    //   counter: 10000
    // })
    // console.log(this.state.counter)

    // const btn = document.querySelector(".btn")
    // btn.onclick = () => {
    //   console.log("-----")
    //   this.setState({ counter: 1000 })
    //   console.log(this.state.counter)
    // }
    // btn.addEventListener("click", () => {
    //   this.setState({ counter: 1000 })
    //   console.log(this.state.counter)
    // })
  }

  changeText() {
    this.setState({ message: "你好啊, 李银河" })
  }

  increment() {
    // this.setState({ counter: this.state.counter + 1 }, () => {
    //   console.log(this.state.counter)
    // })
    // console.log(this.state.counter)
    // this.setState((state, props) => {
    //   return { counter: state.counter + 1 }
    // })
    // this.setState((state, props) => {
    //   return { counter: state.counter + 1 }
    // })
    // this.setState((state, props) => {
    //   return { counter: state.counter + 1 }
    // })

    // setTimeout(() => {
    //   flushSync(() => {
    //     this.setState({ counter: 8888 })
    //     console.log(this.state.counter)
    //   })
    // }, 0);

    flushSync(() => {
      this.setState({ counter: 8888 })
    })
    console.log(this.state.counter)
  }

  render() {
    const { message, counter } = this.state
    console.log("App Render")

    return (
      <div>
        <h2>{message}</h2>
        <h2>当前计数: {counter}</h2>
        <HelloWorld message={message}/>
        <button onClick={e => this.changeText()}>修改文本</button>
        <button className='btn' onClick={e => this.increment()}>+1</button>
      </div>
    )
  }
}

export default App