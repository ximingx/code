import React, { memo } from 'react'

const Product = memo(() => {
  return (
    <div>
      <h1>Product Page</h1>
    </div>
  )
})

export default Product