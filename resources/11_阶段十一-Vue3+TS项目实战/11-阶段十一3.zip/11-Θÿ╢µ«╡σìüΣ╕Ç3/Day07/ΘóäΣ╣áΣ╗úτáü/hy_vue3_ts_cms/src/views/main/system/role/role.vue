<template>
  <div class="role">
    <h2>role</h2>
  </div>
</template>

<script setup lang="ts" name="role"></script>

<style scoped>
.role{
}
</style>
