// export const baseURL = "http://localhost:1888/airbnb/api"
export const baseURL = "http://codercba.com:1888/airbnb/api"
export const TIMEOUT = 10000