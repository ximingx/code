import styled from 'styled-components'

export const LongforWrapper = styled.div`
  margin-top: 32px;
`
