import { HYEventBus } from "hy-event-store"

const eventBus = new HYEventBus()

export default eventBus
